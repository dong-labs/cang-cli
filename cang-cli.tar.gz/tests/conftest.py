"""Pytest 配置和共享 Fixtures

这个文件包含所有测试共享的 fixtures 和配置。
"""

import json
import sqlite3
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
from typer.testing import CliRunner


# =============================================================================
# 数据库 Fixtures
# =============================================================================

@pytest.fixture
def memory_db() -> sqlite3.Connection:
    """创建内存数据库连接

    每个使用此 fixture 的测试都会获得一个独立的内存数据库。
    数据库在测试结束后自动关闭。

    Yields:
        sqlite3.Connection: 配置好 row_factory 的连接对象
    """
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


@pytest.fixture
def memory_db_with_schema(memory_db: sqlite3.Connection) -> sqlite3.Connection:
    """创建带有初始 schema 的内存数据库

    包含 cang_meta 表。

    Yields:
        sqlite3.Connection: 已初始化 schema 的连接对象
    """
    # 创建 cang_meta 表
    memory_db.execute("""
        CREATE TABLE IF NOT EXISTS cang_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    memory_db.commit()
    yield memory_db


@pytest.fixture
def temp_db_file(tmp_path: Path) -> tuple[sqlite3.Connection, Path]:
    """创建临时数据库文件

    使用 pytest 的 tmp_path fixture 创建临时文件。
    临时文件会在测试会话结束后自动清理。

    Args:
        tmp_path: pytest 提供的临时目录

    Yields:
        tuple[sqlite3.Connection, Path]: (连接对象, 数据库文件路径)
    """
    db_path = tmp_path / "test.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    yield conn, db_path
    conn.close()


# =============================================================================
# CLI Fixtures
# =============================================================================

@pytest.fixture
def cli_runner() -> CliRunner:
    """创建 Typer CLI 测试运行器

    用于测试 CLI 命令的输入输出。

    Returns:
        CliRunner: Typer 的测试运行器实例
    """
    return CliRunner()


# =============================================================================
# JSON 响应验证 Helpers
# =============================================================================

class JSONResponseValidator:
    """JSON 响应验证辅助类"""

    @staticmethod
    def parse(output: str) -> dict:
        """解析 JSON 输出

        Args:
            output: CLI 输出的 JSON 字符串

        Returns:
            dict: 解析后的字典

        Raises:
            json.JSONDecodeError: JSON 格式错误
        """
        return json.loads(output)

    @staticmethod
    def assert_success(output: str) -> dict:
        """断言响应为成功格式

        验证:
        - success 为 True
        - 包含 data 字段
        - 不包含 error 字段

        Args:
            output: CLI 输出

        Returns:
            dict: data 字段内容

        Raises:
            AssertionError: 格式验证失败
        """
        data = JSONResponseValidator.parse(output)
        assert data["success"] is True, f"Expected success=True, got: {data}"
        assert "data" in data, f"Missing 'data' field in: {data}"
        assert "error" not in data, f"Unexpected 'error' field in: {data}"
        return data["data"]

    @staticmethod
    def assert_error(output: str, expected_code: str | None = None) -> dict:
        """断言响应为错误格式

        验证:
        - success 为 False
        - 包含 error 字段
        - error 包含 code 和 message
        - 可选验证 code 匹配

        Args:
            output: CLI 输出
            expected_code: 期望的错误代码

        Returns:
            dict: error 字段内容

        Raises:
            AssertionError: 格式验证失败
        """
        data = JSONResponseValidator.parse(output)
        assert data["success"] is False, f"Expected success=False, got: {data}"
        assert "error" in data, f"Missing 'error' field in: {data}"
        assert "data" not in data, f"Unexpected 'data' field in: {data}"

        error = data["error"]
        assert "code" in error, f"Missing 'code' in error: {error}"
        assert "message" in error, f"Missing 'message' in error: {error}"

        if expected_code:
            assert error["code"] == expected_code, f"Expected code={expected_code}, got: {error}"

        return error


@pytest.fixture
def json_validator() -> type[JSONResponseValidator]:
    """提供 JSON 响应验证器

    Returns:
        type[JSONResponseValidator]: 验证器类
    """
    return JSONResponseValidator


# =============================================================================
# Mock Fixtures
# =============================================================================

@pytest.fixture
def mock_db_path(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    """Mock 数据库路径为临时目录

    用于避免测试污染用户主目录的 ~/.cang/

    Args:
        monkeypatch: pytest monkeypatch fixture
        tmp_path: pytest 临时目录

    Returns:
        Path: 临时数据库路径
    """
    test_db_path = tmp_path / ".cang" / "cang.db"

    def mock_get_db_path() -> Path:
        test_db_path.parent.mkdir(parents=True, exist_ok=True)
        return test_db_path

    # 导入前需要 mock，这里假设模块已导入
    # 实际使用时需要在测试中手动 patch
    return test_db_path


# =============================================================================
# 测试数据 Fixtures
# =============================================================================

@pytest.fixture
def sample_account_data() -> dict:
    """示例账户数据

    Returns:
        dict: 符合 accounts 表结构的示例数据
    """
    return {
        "name": "招商银行",
        "type": "checking",
        "balance_cents": 100000,
        "currency": "CNY",
        "is_active": True,
    }


@pytest.fixture
def sample_transaction_data() -> dict:
    """示例交易数据

    Returns:
        dict: 符合 transactions 表结构的示例数据
    """
    return {
        "account_id": 1,
        "amount_cents": -2990,
        "category": "餐饮",
        "payee": "麦当劳",
        "note": "午餐",
        "tx_date": "2026-03-15",
    }
