"""Tests for Cang CLI"""
