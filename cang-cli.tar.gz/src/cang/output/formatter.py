"""统一的 JSON 输出和错误处理

职责:
- 定义统一的错误类型和错误码
- 提供装饰器自动包装命令返回值
- 提供统一的 JSON 输出格式
"""

import json
import functools
from typing import Any, Callable


# ============================================================================
# 错误码定义
# ============================================================================

class ErrorCode:
    """错误码常量"""

    DATABASE_ERROR = "DATABASE_ERROR"
    NOT_FOUND = "NOT_FOUND"
    INVALID_INPUT = "INVALID_INPUT"
    ALREADY_EXISTS = "ALREADY_EXISTS"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


# ============================================================================
# 自定义异常
# ============================================================================

class CangError(Exception):
    """Cang 基础异常类

    所有业务异常都应继承此类。

    Attributes:
        code: 错误码
        message: 人类可读的错误信息
    """

    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message
        super().__init__(message)


class DatabaseError(CangError):
    """数据库错误"""

    def __init__(self, message: str):
        super().__init__(ErrorCode.DATABASE_ERROR, message)


class NotFoundError(CangError):
    """资源不存在错误"""

    def __init__(self, message: str):
        super().__init__(ErrorCode.NOT_FOUND, message)


class InvalidInputError(CangError):
    """输入验证失败错误"""

    def __init__(self, message: str):
        super().__init__(ErrorCode.INVALID_INPUT, message)


class AlreadyExistsError(CangError):
    """资源已存在错误"""

    def __init__(self, message: str):
        super().__init__(ErrorCode.ALREADY_EXISTS, message)


# ============================================================================
# 统一响应格式
# ============================================================================

def success(data: Any = None) -> dict:
    """生成成功响应

    Args:
        data: 返回的数据，可以是任意类型

    Returns:
        dict: 统一格式的成功响应

    Examples:
        >>> success({"id": 1, "name": "test"})
        {'success': True, 'data': {'id': 1, 'name': 'test'}}
        >>> success()
        {'success': True, 'data': None}
    """
    return {
        "success": True,
        "data": data,
    }


def error(code: str, message: str) -> dict:
    """生成错误响应

    Args:
        code: 错误码
        message: 错误信息

    Returns:
        dict: 统一格式的错误响应

    Examples:
        >>> error("NOT_FOUND", "Account not found")
        {'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'Account not found'}}
    """
    return {
        "success": False,
        "error": {
            "code": code,
            "message": message,
        },
    }


def error_from_exception(e: Exception) -> dict:
    """从异常生成错误响应

    如果是 CangError，提取 code 和 message。
    其他异常使用 INTERNAL_ERROR。

    Args:
        e: 异常对象

    Returns:
        dict: 统一格式的错误响应
    """
    if isinstance(e, CangError):
        return error(e.code, e.message)
    return error(ErrorCode.INTERNAL_ERROR, str(e))


# ============================================================================
# JSON 输出
# ============================================================================

def print_json(data: dict) -> None:
    """输出 JSON 到 stdout

    Args:
        data: 要输出的字典数据
    """
    typer_echo(json.dumps(data, ensure_ascii=False, indent=2))


def typer_echo(message: str) -> None:
    """输出到 stdout

    使用独立函数以便测试时可以 mock。

    Args:
        message: 要输出的消息
    """
    print(message, end="")


# ============================================================================
# 装饰器
# ============================================================================

def json_output(func: Callable) -> Callable:
    """装饰器：自动包装函数返回值为统一 JSON 格式

    如果函数正常返回，包装为成功响应。
    如果函数抛出 CangError，包装为错误响应。
    如果函数抛出其他异常，包装为 INTERNAL_ERROR。

    Args:
        func: 被装饰的函数

    Returns:
        Callable: 包装后的函数

    Examples:
        @json_output
        def get_account(account_id: int):
            return {"id": account_id, "name": "Cash"}

        # 输出: {"success": true, "data": {"id": 1, "name": "Cash"}}

        @json_output
        def get_account(account_id: int):
            raise NotFoundError("Account not found")

        # 输出: {"success": false, "error": {"code": "NOT_FOUND", "message": "Account not found"}}
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> None:
        try:
            result = func(*args, **kwargs)
            response = success(result)
        except CangError as e:
            response = error(e.code, e.message)
        except Exception as e:
            response = error_from_exception(e)

        print_json(response)

    return wrapper
